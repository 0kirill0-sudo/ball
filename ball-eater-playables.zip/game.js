(function(){
'use strict';

/* ---------- YouTube Playables SDK (безопасные обёртки) ---------- */
const YT = (typeof ytgame !== 'undefined' && ytgame && ytgame.IN_PLAYABLES_ENV) ? ytgame : null;
function safe(fn){ try{ return fn(); }catch(e){ return undefined; } }
function safeAsync(fn){ try{ return Promise.resolve(fn()).catch(function(){}); }catch(e){ return Promise.resolve(); } }

window.addEventListener('error', function(){ if(YT) safe(function(){ YT.health.logError(); }); });

if(!window.THREE){
  document.body.insertAdjacentHTML('beforeend','<div style="position:fixed;inset:0;display:flex;align-items:center;justify-content:center;padding:24px;text-align:center;z-index:99;background:#9ad8ff">3D engine failed to load.</div>');
  return;
}

/* ---------- Локализация ---------- */
const I18N = {
  ru:{
    title:'Шар-пожиратель', menuText:'Ты — маленький шар на большой арене. Съедай мелочь, расти и поглощай других шаров.',
    ruleGreen:'Зелёное кольцо — можно съесть', ruleRed:'Красное кольцо — убегай, съедят тебя', ruleSlow:'Чем больше шар, тем он медленнее',
    play:'Играть', mass:'Масса', eatenLbl:'Съедено шаров:', boardTitle:'Самые большие',
    hint:'Клик — захватить мышь. Мышь — камера, <b>WASD</b> — ехать туда, куда смотришь, <b>Q/E</b> — поворот, <b>Esc</b> — отпустить курсор.<br>Ешь шары с <span class="g">зелёным</span> кольцом, беги от <span class="r">красного</span>. На телефоне: левый палец — движение, правый — камера.',
    overTitle:'Тебя съели', statMass:'масса', statEaten:'съедено шаров', statBest:'рекорд', again:'Играть снова', you:'Ты',
    shopBtn:'🛍 Магазин', shopTitle:'Магазин', back:'Назад', tabSkins:'Скины', tabHats:'Шапки', tabUps:'Улучшения', statCoins:'монет за игру',
    buy:'Купить', equip:'Надеть', equipped:'Надето ✓', upgrade:'Улучшить', maxed:'Максимум',
    names:["Бублик","Колобок","Пончик","Арбуз","Горошек","Шарик","Мячик","Кекс","Глобус","Пельмень","Мармелад","Комета","Планета","Лимон","Вишня","Банан","Ёжик","Булка","Жучок","Космос","Бусинка","Тыква","Апельсин","Ядро","Леденец","Помидор","Слива","Конфета","Клубника","Мандарин","Ватрушка","Сушка","Пирожок","Карамель","Зефир","Ананас","Кабачок","Баранка","Груша","Малина"]
  },
  en:{
    title:'Ball Eater', menuText:'You are a small ball in a big arena. Eat the little ones, grow, and swallow other balls.',
    ruleGreen:'Green ring — you can eat it', ruleRed:'Red ring — run, it will eat you', ruleSlow:'The bigger the ball, the slower it moves',
    play:'Play', mass:'Mass', eatenLbl:'Balls eaten:', boardTitle:'Biggest balls',
    hint:'Click to capture the mouse. Mouse — camera, <b>WASD</b> — move where you look, <b>Q/E</b> — turn, <b>Esc</b> — release cursor.<br>Eat balls with a <span class="g">green</span> ring, run from a <span class="r">red</span> one. On phones: left thumb moves, right thumb looks around.',
    overTitle:'You got eaten', statMass:'mass', statEaten:'balls eaten', statBest:'best', again:'Play again', you:'You',
    shopBtn:'🛍 Shop', shopTitle:'Shop', back:'Back', tabSkins:'Skins', tabHats:'Hats', tabUps:'Upgrades', statCoins:'coins this run',
    buy:'Buy', equip:'Equip', equipped:'Equipped ✓', upgrade:'Upgrade', maxed:'Max',
    names:["Bubble","Pebble","Donut","Melon","Pea","Orb","Bouncy","Muffin","Globe","Dumpling","Jelly","Comet","Planet","Lemon","Cherry","Banana","Hedgehog","Bun","Beetle","Cosmo","Bead","Pumpkin","Orange","Cannonball","Lollipop","Tomato","Plum","Candy","Berry","Tangerine","Waffle","Pretzel","Pie","Caramel","Marshmallow","Pineapple","Zucchini","Bagel","Pear","Raspberry"]
  }
};
let lang = 'en';
function pickLang(tag){ return /^(ru|be|kk|ky)/i.test(tag || '') ? 'ru' : 'en'; }

/* ---------- Константы ---------- */
const ARENA = 240;         // половина стороны арены (карта 480 x 480)
const BOT_COUNT = 60;
const FOOD_COUNT = 1400;
const SAVE_KEY = 'ball_eater_best';
const SKY = 0x9ad8ff;

/* ---------- Сцена ---------- */
const stage = document.getElementById('stage');
const renderer = new THREE.WebGLRenderer({antialias:true});
renderer.setPixelRatio(Math.min(window.devicePixelRatio||1, 2));
renderer.setSize(window.innerWidth, window.innerHeight);
stage.appendChild(renderer.domElement);

const scene = new THREE.Scene();
scene.background = new THREE.Color(SKY);
scene.fog = new THREE.Fog(SKY, 120, 420);

const camera = new THREE.PerspectiveCamera(60, window.innerWidth/window.innerHeight, 0.5, 1600);
camera.position.set(0, 60, 100);

scene.add(new THREE.HemisphereLight(0xffffff, 0x9bc46a, 1.0));
const sun = new THREE.DirectionalLight(0xfff3d6, 0.75);
sun.position.set(40, 80, 30);
scene.add(sun);

// Лужайка с цветочками
function makeFloorTex(){
  const c = document.createElement('canvas'); c.width = c.height = 256;
  const g = c.getContext('2d');
  g.fillStyle = '#86d94b'; g.fillRect(0,0,256,256);
  g.fillStyle = '#78cc3f'; g.fillRect(0,0,128,128); g.fillRect(128,128,128,128);
  const cols = ['#ff6b9d','#ffd93d','#ffffff','#6bcbff','#ff9f43','#b983ff'];
  for(let i=0;i<30;i++){
    g.fillStyle = cols[i % cols.length];
    g.beginPath(); g.arc(Math.random()*256, Math.random()*256, 2.6+Math.random()*2.4, 0, Math.PI*2); g.fill();
  }
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(ARENA*2/12, ARENA*2/12);
  t.anisotropy = 4;
  return t;
}
const floor = new THREE.Mesh(
  new THREE.PlaneGeometry(ARENA*2, ARENA*2),
  new THREE.MeshStandardMaterial({map:makeFloorTex(), roughness:1, metalness:0})
);
floor.rotation.x = -Math.PI/2;
scene.add(floor);

// Газон за забором
const outer = new THREE.Mesh(
  new THREE.PlaneGeometry(4000, 4000),
  new THREE.MeshStandardMaterial({color:0x64b848, roughness:1})
);
outer.rotation.x = -Math.PI/2; outer.position.y = -0.06;
scene.add(outer);

// Разноцветный забор (инстансы — мало вызовов отрисовки)
(function buildFence(){
  const cols = [0xff595e,0xffca3a,0x8ac926,0x1982c4,0x6a4c93,0xff924c].map(function(c){ return new THREE.Color(c); });
  const SEG = 8;
  const count = Math.floor(ARENA*2/SEG);
  const mat = new THREE.MeshStandardMaterial({color:0xffffff, roughness:0.6});
  const hm = new THREE.InstancedMesh(new THREE.BoxGeometry(SEG, 2.6, 1.6), mat, count*2);
  const vm = new THREE.InstancedMesh(new THREE.BoxGeometry(1.6, 2.6, SEG), mat, count*2);
  const d = new THREE.Object3D();
  let hi = 0, vi = 0;
  for(let n=0;n<count;n++){
    const p = -ARENA + SEG/2 + n*SEG;
    d.position.set(p, 1.3, -ARENA-0.8); d.updateMatrix(); hm.setMatrixAt(hi, d.matrix); hm.setColorAt(hi, cols[n%6]); hi++;
    d.position.set(p, 1.3,  ARENA+0.8); d.updateMatrix(); hm.setMatrixAt(hi, d.matrix); hm.setColorAt(hi, cols[(n+2)%6]); hi++;
    d.position.set(-ARENA-0.8, 1.3, p); d.updateMatrix(); vm.setMatrixAt(vi, d.matrix); vm.setColorAt(vi, cols[(n+1)%6]); vi++;
    d.position.set( ARENA+0.8, 1.3, p); d.updateMatrix(); vm.setMatrixAt(vi, d.matrix); vm.setColorAt(vi, cols[(n+3)%6]); vi++;
  }
  hm.frustumCulled = vm.frustumCulled = false;
  scene.add(hm); scene.add(vm);
})();

// Деревья вокруг арены (инстансы)
(function buildTrees(){
  const N = 320;
  const trunks = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.7, 0.9, 4, 8), new THREE.MeshStandardMaterial({color:0x8d5a2b, roughness:1}), N);
  const leaves = new THREE.InstancedMesh(new THREE.SphereGeometry(1, 12, 10), new THREE.MeshStandardMaterial({color:0xffffff, roughness:0.8}), N);
  const greens = [0x3fae3f,0x56c256,0x2e9a49].map(function(c){ return new THREE.Color(c); });
  const blooms = [0xff8fb1,0xffa94d,0xf2d13a].map(function(c){ return new THREE.Color(c); });
  const d = new THREE.Object3D();
  for(let i=0;i<N;i++){
    const side = Math.floor(Math.random()*4);
    const off = ARENA + 10 + Math.random()*120;
    const al = (Math.random()*2-1) * (ARENA + 120);
    const x = side<2 ? al : (side===2 ? -off : off);
    const z = side<2 ? (side===0 ? -off : off) : al;
    const s = 3 + Math.random()*2.5;
    d.scale.set(1,1,1); d.position.set(x, 2, z); d.updateMatrix();
    trunks.setMatrixAt(i, d.matrix);
    d.scale.set(s, s*0.9, s); d.position.set(x, 4 + s*0.6, z); d.updateMatrix();
    leaves.setMatrixAt(i, d.matrix);
    leaves.setColorAt(i, Math.random()<0.72 ? greens[Math.floor(Math.random()*3)] : blooms[Math.floor(Math.random()*3)]);
  }
  trunks.frustumCulled = leaves.frustumCulled = false;
  scene.add(trunks); scene.add(leaves);
})();

/* ---------- Шары ---------- */
function makeBallTex(){
  const c = document.createElement('canvas'); c.width = 256; c.height = 128;
  const g = c.getContext('2d');
  g.fillStyle = '#ffffff'; g.fillRect(0,0,256,128);
  g.fillStyle = '#d6d8ea';
  for(let i=0;i<8;i+=2) g.fillRect(i*32,0,32,128);
  g.fillStyle = '#ffffff';
  for(let i=0;i<8;i++){ g.beginPath(); g.arc(i*32+16,30,6,0,Math.PI*2); g.fill(); }
  return new THREE.CanvasTexture(c);
}
const ballTex = makeBallTex();
const sphereGeo = new THREE.SphereGeometry(1, 32, 22);
const eyeGeo = new THREE.SphereGeometry(1, 14, 10);
const eyeWhite = new THREE.MeshBasicMaterial({color:0xffffff});
const eyeBlack = new THREE.MeshBasicMaterial({color:0x1d2a4d});
const shadowGeo = new THREE.CircleGeometry(1, 28); shadowGeo.rotateX(-Math.PI/2);
const ringGeo = new THREE.RingGeometry(1.08, 1.3, 44); ringGeo.rotateX(-Math.PI/2);
const shadowMat = new THREE.MeshBasicMaterial({color:0x1d3a10, transparent:true, opacity:0.28, depthWrite:false});

const balls = [];
let player = null;

let avoidHue = 0.12; // цвет скина игрока боты не получают
function botColor(){
  let h; do { h = Math.random(); } while(avoidHue >= 0 && Math.abs(h-avoidHue) < 0.05);
  return new THREE.Color().setHSL(h, 0.72, 0.58);
}

function makeEyes(){
  const eyes = new THREE.Group();
  [-1,1].forEach(function(sx){
    const w = new THREE.Mesh(eyeGeo, eyeWhite);
    w.scale.setScalar(0.25); w.position.set(sx*0.34, 0.38, 0.84);
    const p = new THREE.Mesh(eyeGeo, eyeBlack);
    p.scale.setScalar(0.12); p.position.set(sx*(0.34+0.03), 0.455, 1.0);
    eyes.add(w); eyes.add(p);
  });
  return eyes;
}

function makeHats(){
  const group = new THREE.Group(), map = {};
  function std(c){ return new THREE.MeshStandardMaterial({color:c, roughness:0.5}); }
  // колпак
  (function(){
    const g = new THREE.Group();
    const cone = new THREE.Mesh(new THREE.ConeGeometry(0.42, 0.95, 18), std(0xff6b9d));
    const pom = new THREE.Mesh(new THREE.SphereGeometry(0.1, 10, 8), std(0xffd93d)); pom.position.y = 0.5;
    const band = new THREE.Mesh(new THREE.TorusGeometry(0.35, 0.045, 8, 20), std(0x5ab8ff)); band.rotation.x = Math.PI/2; band.position.y = -0.3;
    g.add(cone); g.add(pom); g.add(band);
    g.position.y = 1.38; g.rotation.z = 0.16; map.party = g;
  })();
  // нимб
  (function(){
    const g = new THREE.Group();
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.42, 0.055, 10, 28), std(0xffd93d)); ring.rotation.x = Math.PI/2;
    g.add(ring); g.position.y = 1.55; map.halo = g;
  })();
  // цилиндр
  (function(){
    const g = new THREE.Group();
    const top = new THREE.Mesh(new THREE.CylinderGeometry(0.34, 0.34, 0.55, 16), std(0x2b2d42)); top.position.y = 0.3;
    const band = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.35, 0.1, 16), std(0xe63957)); band.position.y = 0.1;
    const brim = new THREE.Mesh(new THREE.CylinderGeometry(0.62, 0.62, 0.06, 20), std(0x2b2d42));
    g.add(top); g.add(band); g.add(brim); g.position.y = 0.97; map.top = g;
  })();
  // корона
  (function(){
    const g = new THREE.Group();
    const gold = std(0xffc61a);
    const base = new THREE.Mesh(new THREE.CylinderGeometry(0.46, 0.4, 0.3, 10, 1, true), gold);
    base.material.side = THREE.DoubleSide; base.position.y = 0.15;
    g.add(base);
    for(let k=0;k<5;k++){
      const a = k/5*Math.PI*2;
      const sp = new THREE.Mesh(new THREE.ConeGeometry(0.1, 0.32, 6), gold);
      sp.position.set(Math.sin(a)*0.43, 0.45, Math.cos(a)*0.43);
      g.add(sp);
    }
    const gem = new THREE.Mesh(new THREE.SphereGeometry(0.07, 8, 6), std(0xe63957)); gem.position.set(0, 0.16, 0.44);
    g.add(gem);
    g.position.y = 0.95; map.crown = g;
  })();
  for(const k in map){ map[k].visible = false; group.add(map[k]); }
  return {group:group, map:map};
}

function createBall(isPlayer, idx){
  const mat = new THREE.MeshStandardMaterial({
    color: isPlayer ? 0xffc21f : botColor(),
    map: ballTex, roughness: 0.45, metalness: 0
  });
  const roller = new THREE.Mesh(sphereGeo, mat);
  roller.rotation.set(Math.random()*6, Math.random()*6, Math.random()*6);
  const eyes = makeEyes();
  const group = new THREE.Group();
  group.add(roller); group.add(eyes);
  const hats = isPlayer ? makeHats() : null;
  if(hats) group.add(hats.group);

  const shadow = new THREE.Mesh(shadowGeo, shadowMat);
  shadow.position.y = 0.02;
  const ringMat = new THREE.MeshBasicMaterial({color:0xffffff, transparent:true, opacity:0.9, depthWrite:false, side:THREE.DoubleSide});
  const ring = new THREE.Mesh(ringGeo, ringMat);
  ring.position.y = 0.04; ring.visible = false;
  scene.add(group); scene.add(shadow); scene.add(ring);
  const b = {
    isPlayer:isPlayer, idx:idx, name:'', mesh:group, roller:roller, eyes:eyes, hats:hats, rainbow:false, mat:mat, shadow:shadow, ring:ring, ringMat:ringMat, ringState:'',
    mass:1, r:1, vr:1, x:0, z:0, vx:0, vz:0, dirx:0, dirz:0, face:Math.random()*6.28,
    alive:false, dying:0, eater:null, pulse:0, respawn:0, thinkT:Math.random()*0.3,
    wx:0, wz:0, wt:0
  };
  group.visible = shadow.visible = false;
  balls.push(b);
  return b;
}

function randomSpot(margin){
  return (Math.random()*2-1) * (ARENA - margin);
}

function spawnBot(b, initial){
  let r;
  if(initial){
    r = 0.5 + Math.pow(Math.random(), 2) * 3.4;
  } else {
    const pr = player && player.alive ? player.r : 1;
    r = pr * (0.45 + Math.random()*1.1);
    if(Math.random() < 0.12) r = pr*1.4 + 0.3;
  }
  r = Math.max(0.5, Math.min(12, r));
  const minDist = initial ? 20 : 45;
  let x=0, z=0;
  for(let i=0;i<25;i++){
    x = randomSpot(r+2); z = randomSpot(r+2);
    if(!player || !player.alive || Math.hypot(x-player.x, z-player.z) > minDist + r) break;
  }
  b.mass = r*r; b.r = r; b.vr = r*0.3; b.x = x; b.z = z; b.vx = b.vz = 0;
  b.dirx = b.dirz = 0; b.alive = true; b.dying = 0; b.eater = null; b.pulse = 0; b.wt = 0;
  b.mat.color.copy(botColor());
  b.mesh.visible = b.shadow.visible = true;
  b.ringState = '';
}

player = createBall(true, -1);
for(let i=0;i<BOT_COUNT;i++) createBall(false, i);
balls.forEach(function(b){ if(!b.isPlayer) spawnBot(b, true); });
// для красивого меню часть шаров ставим поближе к центру
balls.forEach(function(b){ if(!b.isPlayer && b.idx < 16){ b.x = (Math.random()*2-1)*70; b.z = (Math.random()*2-1)*70; } });

/* ---------- Еда ---------- */
const foodMesh = new THREE.InstancedMesh(new THREE.SphereGeometry(1, 10, 8), new THREE.MeshBasicMaterial({color:0xffffff}), FOOD_COUNT);
foodMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
foodMesh.frustumCulled = false;
const foodCols = [0xff6b9d,0xffd93d,0x6bdc7a,0x5ab8ff,0xff9f43,0xb983ff].map(function(c){ return new THREE.Color(c); });
const foodDummy = new THREE.Object3D();
const foods = [];
for(let i=0;i<FOOD_COUNT;i++){
  foods.push({x:randomSpot(2), z:randomSpot(2), ph:Math.random()*6.28});
  foodMesh.setColorAt(i, foodCols[i % foodCols.length]);
}
scene.add(foodMesh);

/* ---------- Частицы ---------- */
const partGeo = new THREE.SphereGeometry(1, 8, 6);
const parts = [];
function burst(x, y, z, color, n, scale){
  for(let i=0;i<n;i++){
    const mat = new THREE.MeshBasicMaterial({color:color, transparent:true});
    const m = new THREE.Mesh(partGeo, mat);
    m.position.set(x, y, z);
    m.scale.setScalar(scale*(0.1 + Math.random()*0.12));
    scene.add(m);
    const a = Math.random()*6.283, sp = 3 + Math.random()*5;
    parts.push({m:m, mat:mat, vx:Math.cos(a)*sp, vy:2+Math.random()*4, vz:Math.sin(a)*sp, life:0.6});
  }
}

/* ---------- Звук: только по настройке YouTube ---------- */
let actx = null;
let audioOn = true;
let paused = false, rafId = 0;
if(YT){ audioOn = safe(function(){ return YT.system.isAudioEnabled(); }) !== false; }
function applyAudio(){
  if(!actx) return;
  if(audioOn && !paused){ safe(function(){ actx.resume(); }); }
  else { safe(function(){ actx.suspend(); }); }
}
if(YT){
  safe(function(){ YT.system.onAudioEnabledChange(function(v){ audioOn = !!v; applyAudio(); }); });
}
function initAudio(){
  if(!audioOn) return;
  if(!actx){ try{ actx = new (window.AudioContext||window.webkitAudioContext)(); }catch(e){ actx = null; } }
  applyAudio();
}
function tone(f0, f1, dur, type, vol){
  if(!actx || !audioOn || paused) return;
  try{
    const t = actx.currentTime;
    const o = actx.createOscillator(), g = actx.createGain();
    o.type = type; o.frequency.setValueAtTime(f0, t); o.frequency.exponentialRampToValueAtTime(f1, t+dur);
    g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t+dur);
    o.connect(g); g.connect(actx.destination); o.start(t); o.stop(t+dur+0.02);
  }catch(e){}
}
let lastFoodSnd = 0;

/* ---------- Состояние ---------- */
let state = 'menu';       // menu | play | over
let time = 0, eaten = 0, best = 0, lastScoreShown = -1, hintTimer = 0;
let camYaw = 0, camPitch = 0.75, camSettle = 1, menuAng = 0, camSnap = false, shopAng = 0;
let shopOpen = false, shopTab = 'skins', shopFrom = 'menu', coinsDirty = false, runCoins = 0, autosaveT = 20;
const pv = {skin:null, hat:null};

const $ = function(id){ return document.getElementById(id); };
const scoreVal = $('scoreVal'), eatenVal = $('eatenVal'), lb = $('lb'), hint = $('hint'), radar = $('radar');
const coinVal = $('coinVal'), coinMenu = $('coinMenu'), coinShop = $('coinShop');
const rctx = radar.getContext('2d');

/* ---------- Язык ---------- */
function setLang(l){
  lang = I18N[l] ? l : 'en';
  const d = I18N[lang];
  document.documentElement.lang = lang;
  document.title = d.title;
  document.querySelectorAll('[data-i]').forEach(function(el){ if(d[el.dataset.i] !== undefined) el.textContent = d[el.dataset.i]; });
  hint.innerHTML = d.hint;
  balls.forEach(function(b){ b.name = b.isPlayer ? d.you : d.names[b.idx % d.names.length]; });
  if(shopOpen) renderShop();
}
setLang(pickLang(navigator.language));
async function initLang(){
  if(!YT) return;
  try{ const tag = await YT.system.getLanguage(); setLang(pickLang(tag)); }catch(e){}
}

/* ---------- Данные магазина и сохранения ---------- */
const MAX_LVL = 5;
const SKINS = [
  {id:'sun',    c:0xffc21f, price:0,   ru:'Солнышко',   en:'Sunny'},
  {id:'pink',   c:0xff6b9d, price:60,  ru:'Розовый',    en:'Pink'},
  {id:'sky',    c:0x4cc9f0, price:60,  ru:'Небесный',   en:'Sky'},
  {id:'mint',   c:0x3ddc84, price:90,  ru:'Мятный',     en:'Mint'},
  {id:'violet', c:0x9b5de5, price:90,  ru:'Фиолетовый', en:'Violet'},
  {id:'cherry', c:0xe63957, price:120, ru:'Вишнёвый',   en:'Cherry'},
  {id:'rainbow',c:null,     price:400, ru:'Радуга',     en:'Rainbow'}
];
const HATS = [
  {id:'none',  icon:'🚫', price:0,   ru:'Без шапки', en:'No hat'},
  {id:'party', icon:'🥳', price:80,  ru:'Колпак',    en:'Party hat'},
  {id:'halo',  icon:'😇', price:100, ru:'Нимб',      en:'Halo'},
  {id:'top',   icon:'🎩', price:120, ru:'Цилиндр',   en:'Top hat'},
  {id:'crown', icon:'👑', price:200, ru:'Корона',    en:'Crown'}
];
const UPS = [
  {id:'speed',  icon:'⚡', costs:[60,120,220,380,600],  ru:'Скорость',        en:'Speed',
    ruD:'Быстрее катишься: +7% за уровень', enD:'Roll faster: +7% per level'},
  {id:'size',   icon:'🏀', costs:[60,120,220,380,600],  ru:'Стартовый размер', en:'Start size',
    ruD:'Начинаешь крупнее: +35% массы за уровень', enD:'Start bigger: +35% mass per level'},
  {id:'magnet', icon:'🧲', costs:[60,120,220,380,600],  ru:'Магнит',          en:'Magnet',
    ruD:'Собираешь еду с большего расстояния', enD:'Collect food from further away'},
  {id:'coins',  icon:'💰', costs:[100,200,350,550,800], ru:'Жадность',        en:'Greed',
    ruD:'Больше монет за шар: +15% за уровень', enD:'More coins per ball: +15% per level'}
];
const save = {best:0, coins:0, owned:{sun:1, none:1}, skin:'sun', hat:'none', up:{speed:0, size:0, magnet:0, coins:0}};
function byId(list, id){ for(let i=0;i<list.length;i++){ if(list[i].id === id) return list[i]; } return null; }

function mergeSave(d){
  if(!d || typeof d !== 'object') return;
  save.best = Math.max(0, d.best|0);
  save.coins = Math.max(0, d.coins|0);
  if(d.owned && typeof d.owned === 'object'){
    for(const k in d.owned){ if(d.owned[k] && (byId(SKINS,k) || byId(HATS,k))) save.owned[k] = 1; }
  }
  if(d.up && typeof d.up === 'object'){
    UPS.forEach(function(u){ save.up[u.id] = clamp(d.up[u.id]|0, 0, MAX_LVL); });
  }
  if(byId(SKINS, d.skin) && save.owned[d.skin]) save.skin = d.skin;
  if(byId(HATS, d.hat) && save.owned[d.hat]) save.hat = d.hat;
}
async function loadBest(){
  try{
    let raw = null;
    if(YT){ raw = await YT.game.loadData(); }
    else { raw = localStorage.getItem(SAVE_KEY); }
    if(raw){
      let d = null;
      try{ d = JSON.parse(raw); }catch(e){ d = {best: parseInt(raw,10)||0}; }
      mergeSave(d);
    }
  }catch(e){}
  best = save.best;
  refreshWallet(); applyCosmetics();
}
function saveBest(){
  save.best = best;
  const s = JSON.stringify(save);
  if(YT){ safeAsync(function(){ return YT.game.saveData(s); }); }
  else { safe(function(){ localStorage.setItem(SAVE_KEY, s); }); }
}
window.addEventListener('pagehide', function(){ if(coinsDirty){ coinsDirty = false; saveBest(); } });

/* ---------- Предпросмотр шара в магазине ---------- */
const PV = {x: ARENA+220, z: 0};
const preview = (function(){
  const mat = new THREE.MeshStandardMaterial({color:0xffc21f, map:ballTex, roughness:0.45, metalness:0});
  const roller = new THREE.Mesh(sphereGeo, mat);
  const eyes = makeEyes();
  const hats = makeHats();
  const group = new THREE.Group();
  group.add(roller); group.add(eyes); group.add(hats.group);
  group.position.set(PV.x, 1, PV.z);
  const shadow = new THREE.Mesh(shadowGeo, shadowMat);
  shadow.position.set(PV.x, 0.02, PV.z); shadow.scale.setScalar(1.1);
  group.visible = shadow.visible = false;
  scene.add(group); scene.add(shadow);
  return {mesh:group, roller:roller, eyes:eyes, mat:mat, hats:hats, shadow:shadow, rainbow:false};
})();

function setLook(o, skinId, hatId){
  const sk = byId(SKINS, skinId) || SKINS[0];
  o.rainbow = sk.c === null;
  if(!o.rainbow) o.mat.color.setHex(sk.c);
  for(const k in o.hats.map) o.hats.map[k].visible = (k === hatId);
}
function applyCosmetics(){
  setLook(player, save.skin, save.hat);
  setLook(preview, pv.skin || save.skin, pv.hat || save.hat);
  const sk = byId(SKINS, save.skin) || SKINS[0];
  if(sk.c === null){ avoidHue = -1; }
  else { const hsl = {}; new THREE.Color(sk.c).getHSL(hsl); avoidHue = hsl.h; }
}

/* ---------- Магазин: интерфейс ---------- */
function refreshWallet(){
  coinVal.textContent = save.coins; coinMenu.textContent = save.coins; coinShop.textContent = save.coins;
}
function popCoins(n){
  const d = document.createElement('div');
  d.className = 'pop'; d.textContent = '+' + n + ' 🪙';
  $('pops').appendChild(d);
  setTimeout(function(){ if(d.parentNode) d.parentNode.removeChild(d); }, 1000);
}
function el(tag, cls, text){
  const e = document.createElement(tag);
  if(cls) e.className = cls;
  if(text !== undefined) e.textContent = text;
  return e;
}
function hex(c){ return '#' + ('000000' + c.toString(16)).slice(-6); }
function spend(n){ if(save.coins < n) return false; save.coins -= n; return true; }
function afterPurchase(){
  tone(500, 1000, 0.18, 'triangle', 0.1);
  saveBest(); coinsDirty = false;
  refreshWallet(); applyCosmetics(); renderShop();
}

function renderShop(){
  const d = I18N[lang], g = $('shopGrid');
  g.innerHTML = '';
  coinShop.textContent = save.coins;
  document.querySelectorAll('#shop .tab').forEach(function(t){ t.classList.toggle('on', t.dataset.tab === shopTab); });

  if(shopTab === 'ups'){
    UPS.forEach(function(u){
      const lvl = save.up[u.id], maxed = lvl >= MAX_LVL, cost = maxed ? 0 : u.costs[lvl];
      const card = el('div', 'item');
      const sw = el('div', 'sw', u.icon); sw.style.background = '#eef2ff';
      card.appendChild(sw);
      card.appendChild(el('div', 'nm', u[lang]));
      card.appendChild(el('div', 'pips', '●'.repeat(lvl) + '○'.repeat(MAX_LVL - lvl)));
      card.appendChild(el('div', 'ds', u[lang + 'D']));
      const b = el('button', '', maxed ? d.maxed : d.upgrade + ' 🪙' + cost);
      b.disabled = maxed || save.coins < cost;
      b.addEventListener('click', function(){ if(spend(cost)){ save.up[u.id]++; afterPurchase(); } });
      card.appendChild(b);
      g.appendChild(card);
    });
    return;
  }

  const kind = shopTab === 'skins' ? 'skin' : 'hat';
  const list = kind === 'skin' ? SKINS : HATS;
  list.forEach(function(it){
    const owned = !!save.owned[it.id], equipped = save[kind] === it.id;
    const card = el('div', 'item' + ((pv[kind] || save[kind]) === it.id ? ' sel' : ''));
    const sw = el('div', 'sw', it.icon || '');
    if(kind === 'skin'){
      sw.style.background = it.c === null ? 'conic-gradient(#ff595e,#ffca3a,#8ac926,#1982c4,#6a4c93,#ff595e)' : hex(it.c);
    } else { sw.style.background = '#eef2ff'; }
    card.appendChild(sw);
    card.appendChild(el('div', 'nm', it[lang]));
    const b = el('button', equipped ? 'eq' : '', equipped ? d.equipped : (owned ? d.equip : d.buy + ' 🪙' + it.price));
    b.disabled = equipped || (!owned && save.coins < it.price);
    b.addEventListener('click', function(e){
      e.stopPropagation();
      if(!owned){ if(!spend(it.price)) return; save.owned[it.id] = 1; }
      save[kind] = it.id; pv[kind] = null;
      afterPurchase();
    });
    card.appendChild(b);
    // нажми на карточку — примерь на шаре, не покупая
    card.addEventListener('click', function(){ pv[kind] = it.id; applyCosmetics(); renderShop(); });
    g.appendChild(card);
  });
}

function openShop(from){
  shopFrom = from; shopOpen = true; pv.skin = pv.hat = null;
  $('menu').classList.add('hidden'); $('over').classList.add('hidden'); $('shop').classList.remove('hidden');
  preview.mesh.visible = preview.shadow.visible = true;
  camSnap = true;
  applyCosmetics(); renderShop();
}
function closeShop(){
  shopOpen = false; pv.skin = pv.hat = null;
  $('shop').classList.add('hidden');
  preview.mesh.visible = preview.shadow.visible = false;
  $(shopFrom === 'over' ? 'over' : 'menu').classList.remove('hidden');
  camSnap = true;
  applyCosmetics(); refreshWallet();
}
$('shopBtn1').addEventListener('click', function(){ openShop('menu'); });
$('shopBtn2').addEventListener('click', function(){ openShop('over'); });
$('shopBack').addEventListener('click', closeShop);
document.querySelectorAll('#shop .tab').forEach(function(t){
  t.addEventListener('click', function(){ shopTab = t.dataset.tab; renderShop(); });
});
applyCosmetics();
refreshWallet();

/* ---------- Мышь как в Майнкрафте (pointer lock) ---------- */
const SENS = 0.0026;
function clamp(v, a, b){ return Math.max(a, Math.min(b, v)); }
function lookDelta(dx, dy){
  camYaw -= dx*SENS;
  camPitch = clamp(camPitch + dy*SENS, 0.18, 1.35);
}
function isLocked(){ return document.pointerLockElement === stage; }
function lockMouse(){
  if(!stage.requestPointerLock) return;
  try{ const p = stage.requestPointerLock(); if(p && p.catch) p.catch(function(){}); }catch(e){}
}
function unlockMouse(){ safe(function(){ if(document.exitPointerLock) document.exitPointerLock(); }); }
document.addEventListener('mousemove', function(e){
  if(isLocked() && state==='play' && !paused) lookDelta(e.movementX||0, e.movementY||0);
});
document.addEventListener('pointerlockchange', function(){
  if(state==='play' && !isLocked()){ hint.classList.remove('off'); hintTimer = 7; }
});

/* ---------- Управление ---------- */
function maxSpeed(b){ return 21 / Math.pow(Math.max(b.r,0.5), 0.35); }

const keys = {};
window.addEventListener('keydown', function(e){
  keys[e.code] = true; initAudio();
  if(e.code==='Escape' && shopOpen){ closeShop(); return; }
  if(e.code.indexOf('Arrow')===0 || e.code==='Space') e.preventDefault();
  if((e.code==='Enter'||e.code==='Space') && state!=='play' && !paused && !shopOpen){
    if(!document.activeElement || document.activeElement.tagName!=='BUTTON') startGame();
  }
});
window.addEventListener('keyup', function(e){ keys[e.code] = false; });
window.addEventListener('blur', function(){ for(const k in keys) keys[k] = false; });

const joyEl = $('joy'), knob = joyEl.querySelector('i');
const joy = {id:null, ox:0, oy:0, x:0, y:0};
const lk = {id:null, x:0, y:0};
const mouse = {down:false, x:0, y:0};
const JOY_R = 55;

stage.addEventListener('pointerdown', function(e){
  initAudio();
  if(e.pointerType === 'mouse'){
    if(e.button !== 0) return;
    mouse.down = true; mouse.x = e.clientX; mouse.y = e.clientY;
    if(state==='play' && !isLocked()) lockMouse();
    try{ stage.setPointerCapture(e.pointerId); }catch(err){}
    return;
  }
  // касание: левая половина — движение, правая — камера
  if(e.clientX < window.innerWidth*0.5){
    if(joy.id !== null) return;
    joy.id = e.pointerId; joy.ox = e.clientX; joy.oy = e.clientY; joy.x = joy.y = 0;
    joyEl.style.left = e.clientX+'px'; joyEl.style.top = e.clientY+'px'; joyEl.style.display = 'block';
    knob.style.transform = 'translate(0,0)';
  } else {
    if(lk.id !== null) return;
    lk.id = e.pointerId; lk.x = e.clientX; lk.y = e.clientY;
  }
  try{ stage.setPointerCapture(e.pointerId); }catch(err){}
});
stage.addEventListener('pointermove', function(e){
  if(e.pointerType === 'mouse'){
    if(!isLocked() && mouse.down && state==='play'){
      lookDelta(e.clientX-mouse.x, e.clientY-mouse.y);
      mouse.x = e.clientX; mouse.y = e.clientY;
    }
    return;
  }
  if(e.pointerId === joy.id){
    let dx = e.clientX-joy.ox, dy = e.clientY-joy.oy;
    const l = Math.hypot(dx,dy);
    if(l > JOY_R){ dx = dx/l*JOY_R; dy = dy/l*JOY_R; }
    knob.style.transform = 'translate('+dx+'px,'+dy+'px)';
    joy.x = dx/JOY_R; joy.y = dy/JOY_R;
    if(Math.hypot(joy.x,joy.y) < 0.12){ joy.x = joy.y = 0; }
  } else if(e.pointerId === lk.id && state==='play'){
    lookDelta((e.clientX-lk.x)*1.25, (e.clientY-lk.y)*1.25);
    lk.x = e.clientX; lk.y = e.clientY;
  }
});
function pointerEnd(e){
  if(e && e.pointerType === 'mouse'){ mouse.down = false; return; }
  if(!e || e.pointerId === joy.id){ joy.id = null; joy.x = joy.y = 0; joyEl.style.display = 'none'; }
  if(!e || e.pointerId === lk.id){ lk.id = null; }
}
stage.addEventListener('pointerup', pointerEnd);
stage.addEventListener('pointercancel', pointerEnd);

// Ввод в плоскости экрана: x — вправо, y — назад (вниз)
function getInput(){
  let x = (keys.KeyD||keys.ArrowRight ? 1:0) - (keys.KeyA||keys.ArrowLeft ? 1:0);
  let y = (keys.KeyS||keys.ArrowDown ? 1:0) - (keys.KeyW||keys.ArrowUp ? 1:0);
  x += joy.x; y += joy.y;
  const l = Math.hypot(x,y);
  if(l > 1){ x/=l; y/=l; }
  return {x:x, y:y};
}

$('play').addEventListener('click', function(){ startGame(); lockMouse(); });
$('again').addEventListener('click', function(){ startGame(); lockMouse(); });
window.addEventListener('resize', function(){
  camera.aspect = window.innerWidth/window.innerHeight; camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});

/* ---------- Игра ---------- */
function startGame(){
  initAudio();
  player.x = 0; player.z = 0; player.vx = player.vz = 0; player.dirx = player.dirz = 0;
  player.mass = 1 + 0.35*save.up.size; player.r = Math.sqrt(player.mass); player.vr = 0.4; player.pulse = 0;
  player.alive = true; player.dying = 0; player.eater = null;
  player.mesh.visible = player.shadow.visible = true;
  camYaw = 0; camPitch = 0.75; camSettle = 0;
  player.face = Math.PI;
  balls.forEach(function(b){ if(!b.isPlayer) spawnBot(b, true); });
  eaten = 0; runCoins = 0; lastScoreShown = -1; hintTimer = 0;
  hint.classList.remove('off');
  eatenVal.textContent = '0';
  $('menu').classList.add('hidden'); $('over').classList.add('hidden');
  radar.style.display = 'block';
  state = 'play';
}

function endGame(){
  state = 'over';
  radar.style.display = 'none';
  unlockMouse();
  const score = Math.round(player.mass*100);
  if(score > best){ best = score; }
  saveBest(); coinsDirty = false;
  $('fc').textContent = runCoins;
  if(YT && score > 0){ safeAsync(function(){ return YT.engagement.sendScore({value:score}); }); }
  $('fs').textContent = score; $('fe').textContent = eaten; $('fb').textContent = best;
  tone(380, 70, 0.6, 'sawtooth', 0.09);
  $('over').classList.remove('hidden');
}

function eatBall(a, b){
  a.mass = Math.min(300, a.mass + b.mass*0.85);
  a.r = Math.sqrt(a.mass);
  a.pulse = 0.25;
  b.dying = 0.2; b.eater = a;
  burst(b.x, b.vr, b.z, b.mat.color.getHex(), 10, Math.max(1, b.vr*0.7));
  if(a.isPlayer){
    eaten++; eatenVal.textContent = eaten;
    const gain = Math.max(1, Math.round((2 + b.r*3) * (1 + 0.15*save.up.coins)));
    save.coins += gain; runCoins += gain; coinsDirty = true;
    coinVal.textContent = save.coins; popCoins(gain);
    tone(260, 760, 0.16, 'triangle', 0.1);
  }
}
function eatFood(a, f){
  a.mass = Math.min(300, a.mass + 0.1);
  a.r = Math.sqrt(a.mass);
  f.x = randomSpot(2); f.z = randomSpot(2);
  if(a.isPlayer && time - lastFoodSnd > 0.06){ lastFoodSnd = time; tone(700, 1100, 0.07, 'sine', 0.05); }
}

/* ---------- ИИ ботов ---------- */
function think(b){
  let threat=null, td=1e9, prey=null, pd=1e9;
  for(let i=0;i<balls.length;i++){
    const o = balls[i];
    if(o===b || !o.alive || o.dying>0) continue;
    const d = Math.hypot(o.x-b.x, o.z-b.z);
    if(o.r > b.r*1.12){ if(d < 18+o.r*2 && d < td){ td=d; threat=o; } }
    else if(b.r > o.r*1.12){ if(d < 22+b.r*2 && d < pd){ pd=d; prey=o; } }
  }
  let dx=0, dz=0;
  if(threat){ dx = b.x-threat.x; dz = b.z-threat.z; }
  else if(prey && Math.random() < 0.92){ dx = prey.x-b.x; dz = prey.z-b.z; }
  else {
    let fd=1e9, fb=null;
    for(let i=0;i<foods.length;i++){ const f=foods[i]; const d=(f.x-b.x)*(f.x-b.x)+(f.z-b.z)*(f.z-b.z); if(d<fd){ fd=d; fb=f; } }
    if(fb && fd < 18*18){ dx = fb.x-b.x; dz = fb.z-b.z; }
    else {
      b.wt -= 0.2;
      if(b.wt <= 0 || Math.hypot(b.wx-b.x, b.wz-b.z) < 3){
        b.wx = randomSpot(6); b.wz = randomSpot(6); b.wt = 4 + Math.random()*6;
      }
      dx = b.wx-b.x; dz = b.wz-b.z;
    }
  }
  const l = Math.hypot(dx,dz);
  if(l > 0.0001){ dx/=l; dz/=l; }
  const m = ARENA-10; let px=0, pz=0;
  if(b.x >  m) px = -(b.x-m)/10;
  if(b.x < -m) px = -(b.x+m)/10;
  if(b.z >  m) pz = -(b.z-m)/10;
  if(b.z < -m) pz = -(b.z+m)/10;
  b.dirx = dx + px*1.6; b.dirz = dz + pz*1.6;
}

/* ---------- Пауза / возобновление (YouTube) ---------- */
function pauseGame(){
  if(paused) return;
  paused = true;
  if(coinsDirty){ coinsDirty = false; saveBest(); }
  cancelAnimationFrame(rafId);
  for(const k in keys) keys[k] = false;
  pointerEnd(null);
  mouse.down = false;
  applyAudio();
}
function resumeGame(){
  if(!paused) return;
  paused = false;
  last = performance.now();
  rafId = requestAnimationFrame(frame);
  applyAudio();
}
if(YT){
  safe(function(){ YT.system.onPause(pauseGame); });
  safe(function(){ YT.system.onResume(resumeGame); });
} else {
  document.addEventListener('visibilitychange', function(){ if(document.hidden) pauseGame(); else resumeGame(); });
}

/* ---------- Обновление ---------- */
const axis = new THREE.Vector3();
const camLook = new THREE.Vector3(0,0,0);
const camPos = new THREE.Vector3(0,60,100);
const tpv = new THREE.Vector3(), tlv = new THREE.Vector3();
let lbTimer = 0;

function moveBall(b, dt){
  const sp = maxSpeed(b) * (b.isPlayer ? (1 + 0.07*save.up.speed) : 0.93);
  let dx = b.dirx, dz = b.dirz;
  const l = Math.hypot(dx,dz);
  if(l > 1){ dx/=l; dz/=l; }
  const k = Math.min(1, (b.isPlayer ? 9 : 5) * dt);
  b.vx += (dx*sp - b.vx) * k;
  b.vz += (dz*sp - b.vz) * k;
  b.x += b.vx*dt; b.z += b.vz*dt;
  const lim = ARENA - b.r;
  if(b.x >  lim){ b.x =  lim; b.vx = 0; }
  if(b.x < -lim){ b.x = -lim; b.vx = 0; }
  if(b.z >  lim){ b.z =  lim; b.vz = 0; }
  if(b.z < -lim){ b.z = -lim; b.vz = 0; }
  const spd = Math.hypot(b.vx,b.vz);
  if(spd > 0.01){
    axis.set(b.vz, 0, -b.vx).normalize();
    b.roller.rotateOnWorldAxis(axis, spd*dt/Math.max(b.vr,0.3));
  }
  if(spd > 0.6){
    let d = Math.atan2(b.vx, b.vz) - b.face;
    d = Math.atan2(Math.sin(d), Math.cos(d));
    b.face += d * Math.min(1, 10*dt);
  }
  b.eyes.rotation.y = b.face;
}

function update(dt){
  time += dt;
  if(player.rainbow) player.mat.color.setHSL((time*0.25)%1, 0.72, 0.58);
  if(preview.rainbow) preview.mat.color.setHSL((time*0.25)%1, 0.72, 0.58);
  autosaveT -= dt;
  if(autosaveT <= 0){ autosaveT = 20; if(coinsDirty){ coinsDirty = false; saveBest(); } }

  if(state==='play'){
    if(keys.KeyQ) camYaw += 2.0*dt;
    if(keys.KeyE) camYaw -= 2.0*dt;
  } else if(state==='over'){
    camYaw += 0.15*dt;
  }
  // направления относительно камеры
  const fx = -Math.sin(camYaw), fz = -Math.cos(camYaw);
  const rx =  Math.cos(camYaw), rz = -Math.sin(camYaw);

  if(state==='play' && player.alive && player.dying<=0){
    const v = getInput();
    player.dirx = rx*v.x - fx*v.y;
    player.dirz = rz*v.x - fz*v.y;
    hintTimer += dt;
    if(hintTimer > 12) hint.classList.add('off');
  } else { player.dirx = player.dirz = 0; }

  for(let i=0;i<balls.length;i++){
    const b = balls[i];
    if(!b.alive){
      if(!b.isPlayer){ b.respawn -= dt; if(b.respawn <= 0) spawnBot(b, false); }
      continue;
    }
    if(b.dying > 0){
      b.dying -= dt;
      const e = b.eater;
      if(e){ const k = Math.min(1, 14*dt); b.x += (e.x-b.x)*k; b.z += (e.z-b.z)*k; }
      if(b.dying <= 0){
        b.alive = false;
        b.mesh.visible = b.shadow.visible = b.ring.visible = false;
        if(b.isPlayer) endGame(); else b.respawn = 2 + Math.random()*2;
      }
      continue;
    }
    if(!b.isPlayer){
      b.thinkT -= dt;
      if(b.thinkT <= 0){ b.thinkT = 0.18 + Math.random()*0.12; think(b); }
    }
    moveBall(b, dt);
  }

  // мягкое столкновение: шары, которые не могут съесть друг друга, не слипаются
  for(let i=0;i<balls.length;i++){
    const a = balls[i];
    if(!a.alive || a.dying>0) continue;
    for(let j=i+1;j<balls.length;j++){
      const b = balls[j];
      if(!b.alive || b.dying>0) continue;
      if(a.r > b.r*1.12 || b.r > a.r*1.12) continue;
      let dx = b.x-a.x, dz = b.z-a.z;
      const d = Math.hypot(dx,dz), minD = (a.r+b.r)*0.95;
      if(d < minD){
        if(d < 0.001){ dx = Math.random()-0.5; dz = Math.random()-0.5; }
        const l = Math.hypot(dx,dz) || 1;
        const push = (minD-d)*0.5;
        dx /= l; dz /= l;
        a.x -= dx*push; a.z -= dz*push; b.x += dx*push; b.z += dz*push;
      }
    }
  }

  for(let i=0;i<balls.length;i++){
    const a = balls[i];
    if(!a.alive || a.dying>0) continue;
    for(let j=0;j<balls.length;j++){
      const b = balls[j];
      if(a===b || !b.alive || b.dying>0) continue;
      if(a.r > b.r*1.12){
        const d = Math.hypot(a.x-b.x, a.z-b.z);
        if(d < a.r - b.r*0.3){ eatBall(a, b); }
      }
    }
    const mg = a.isPlayer ? 1 + 0.18*save.up.magnet : 1;
    const rr = a.r*a.r*0.9*mg*mg;
    for(let j=0;j<foods.length;j++){
      const f = foods[j];
      const dx = f.x-a.x, dz = f.z-a.z;
      if(dx*dx + dz*dz < rr) eatFood(a, f);
    }
  }

  for(let i=0;i<balls.length;i++){
    const b = balls[i];
    if(!b.alive) continue;
    b.vr += (b.r - b.vr) * Math.min(1, 10*dt);
    b.pulse *= Math.max(0, 1 - 8*dt);
    let s = b.vr * (1 + b.pulse);
    if(b.dying > 0) s *= Math.max(0, b.dying/0.2);
    s = Math.max(s, 0.001);
    b.mesh.scale.setScalar(s);
    b.mesh.position.set(b.x, s, b.z);
    b.shadow.position.x = b.x; b.shadow.position.z = b.z;
    b.shadow.scale.setScalar(s*1.1);

    // кольца: белое — ты, красное — опасен, зелёное — можно съесть
    let st = '';
    if(b.isPlayer){ if(state!=='menu' && b.dying<=0) st = 'p'; }
    else if(state==='play' && player.alive && b.dying<=0){
      if(b.r > player.r*1.12) st = 'r';
      else if(player.r > b.r*1.12) st = 'g';
    }
    if(st !== b.ringState){
      b.ringState = st;
      b.ring.visible = st !== '';
      if(st==='r') b.ringMat.color.set(0xe63957);
      if(st==='g') b.ringMat.color.set(0x22c55e);
      if(st==='p') b.ringMat.color.set(0xffffff);
    }
    if(b.ring.visible){
      b.ring.position.x = b.x; b.ring.position.z = b.z;
      b.ring.scale.setScalar(b.vr*1.02);
    }
  }

  for(let i=0;i<foods.length;i++){
    const f = foods[i];
    foodDummy.position.set(f.x, 0.32 + Math.sin(time*2.5 + f.ph)*0.07, f.z);
    foodDummy.scale.setScalar(0.27);
    foodDummy.updateMatrix();
    foodMesh.setMatrixAt(i, foodDummy.matrix);
  }
  foodMesh.instanceMatrix.needsUpdate = true;

  for(let i=parts.length-1; i>=0; i--){
    const p = parts[i];
    p.life -= dt; p.vy -= 18*dt;
    p.m.position.x += p.vx*dt; p.m.position.y = Math.max(0.05, p.m.position.y + p.vy*dt); p.m.position.z += p.vz*dt;
    p.mat.opacity = Math.max(0, p.life/0.6);
    if(p.life <= 0){ scene.remove(p.m); p.mat.dispose(); parts.splice(i,1); }
  }

  // камера от третьего лица, вращается мышью
  if(shopOpen){
    shopAng += dt*0.5;
    tpv.set(PV.x + Math.sin(shopAng)*6, 2.8, PV.z + Math.cos(shopAng)*6);
    tlv.set(PV.x, -0.4, PV.z);
    preview.eyes.rotation.y = shopAng;
    preview.roller.rotation.y += dt*0.6;
  } else if(state==='menu'){
    menuAng += dt*0.08;
    tpv.set(Math.sin(menuAng)*85, 55, Math.cos(menuAng)*85);
    tlv.set(0,0,0);
  } else {
    const vr = Math.max(player.vr, 1);
    const k = state==='over' ? 1.4 : 1;
    const dist = (9 + vr*5.2) * k;
    const cp = Math.cos(camPitch), sp = Math.sin(camPitch);
    tpv.set(player.x + Math.sin(camYaw)*cp*dist, vr*0.8 + sp*dist, player.z + Math.cos(camYaw)*cp*dist);
    tlv.set(player.x, vr*0.6, player.z);
  }
  if(state==='play' && camSettle < 1) camSettle = Math.min(1, camSettle + dt/0.9);
  const ck = (camSnap || (state==='play' && camSettle >= 1)) ? 1 : Math.min(1, 3.5*dt);
  camSnap = false;
  camPos.lerp(tpv, ck); camLook.lerp(tlv, ck);
  camera.position.copy(camPos);
  camera.lookAt(camLook);

  if(state==='play'){
    const sc = Math.round(player.mass*100);
    if(sc !== lastScoreShown){ lastScoreShown = sc; scoreVal.textContent = sc; }
    drawRadar(fx, fz, rx, rz);
  }
  lbTimer -= dt;
  if(lbTimer <= 0){ lbTimer = 0.5; updateBoard(); }
}

/* ---------- Радар (карта большая, поэтому нужен) ---------- */
const RADAR_RANGE = 110;
function drawRadar(fx, fz, rx, rz){
  const c = rctx, S = radar.width, h = S/2, sc = (h-6)/RADAR_RANGE;
  c.clearRect(0,0,S,S);
  c.save();
  c.beginPath(); c.arc(h,h,h-2,0,Math.PI*2); c.clip();
  c.fillStyle = 'rgba(134,217,75,0.72)'; c.fillRect(0,0,S,S);

  function toRadar(wx, wz){
    const dx = wx-player.x, dz = wz-player.z;
    return [h + (dx*rx + dz*rz)*sc, h - (dx*fx + dz*fz)*sc];
  }
  // границы арены
  c.strokeStyle = '#ff595e'; c.lineWidth = 5; c.beginPath();
  [[-ARENA,-ARENA],[ARENA,-ARENA],[ARENA,ARENA],[-ARENA,ARENA]].forEach(function(p, i){
    const q = toRadar(p[0], p[1]);
    if(i===0) c.moveTo(q[0], q[1]); else c.lineTo(q[0], q[1]);
  });
  c.closePath(); c.stroke();

  for(let i=0;i<balls.length;i++){
    const b = balls[i];
    if(b.isPlayer || !b.alive || b.dying>0) continue;
    const q = toRadar(b.x, b.z);
    if(Math.hypot(q[0]-h, q[1]-h) > h-4) continue;
    c.fillStyle = b.r > player.r*1.12 ? '#e63957' : (player.r > b.r*1.12 ? '#1f9d55' : '#ffffff');
    c.beginPath(); c.arc(q[0], q[1], clamp(b.r*sc*0.9, 4, 16), 0, Math.PI*2); c.fill();
    c.strokeStyle = 'rgba(29,42,77,.55)'; c.lineWidth = 2; c.stroke();
  }
  // ты — стрелка вверх (вверх = куда смотрит камера)
  c.fillStyle = '#ffc21f'; c.strokeStyle = '#1d2a4d'; c.lineWidth = 3;
  c.beginPath(); c.moveTo(h, h-14); c.lineTo(h+10, h+10); c.lineTo(h-10, h+10); c.closePath(); c.fill(); c.stroke();
  c.restore();
  c.strokeStyle = 'rgba(255,255,255,0.95)'; c.lineWidth = 5;
  c.beginPath(); c.arc(h,h,h-3,0,Math.PI*2); c.stroke();
}

function updateBoard(){
  const list = balls.filter(function(b){ return b.alive && !(b.isPlayer && state==='menu'); }).sort(function(a,b){ return b.mass-a.mass; });
  let html = '';
  list.slice(0,5).forEach(function(b){
    html += '<li class="'+(b.isPlayer?'me':'')+'"><span>'+b.name+'</span><b>'+Math.round(b.mass*100)+'</b></li>';
  });
  const idx = list.indexOf(player);
  if(idx >= 5){
    html += '<li class="me"><span>'+(idx+1)+'. '+I18N[lang].you+'</span><b>'+Math.round(player.mass*100)+'</b></li>';
  }
  lb.innerHTML = html;
}

/* ---------- Цикл и сигналы готовности для YouTube ---------- */
let last = performance.now();
let firstFrameSent = false;

function timeout(ms){ return new Promise(function(res){ setTimeout(res, ms); }); }

function frame(now){
  if(paused) return;
  rafId = requestAnimationFrame(frame);
  const dt = Math.min(0.05, (now-last)/1000); last = now;
  update(dt);
  renderer.render(scene, camera);

  if(!firstFrameSent){
    firstFrameSent = true;
    if(YT) safe(function(){ YT.game.firstFrameReady(); });
    // gameReady — когда меню уже показано и с ним можно взаимодействовать
    Promise.race([Promise.all([loadBest(), initLang()]), timeout(2500)]).then(function(){
      $('fb').textContent = best;
      if(YT) safe(function(){ YT.game.gameReady(); });
    });
  }
}
rafId = requestAnimationFrame(frame);
})();
